import subprocess

p = subprocess.Popen(["gulp"], shell=True)
p.wait()