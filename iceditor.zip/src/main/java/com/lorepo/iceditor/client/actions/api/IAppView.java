package com.lorepo.iceditor.client.actions.api;

public interface IAppView {
	public int getPageScrollTopPosition();
}
