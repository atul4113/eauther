package com.lorepo.iceditor.client.module.api;

import com.lorepo.icplayer.client.model.Content;

public interface IEditorServices {

	Content getContent();
}
