package com.lorepo.iceditor.client.ui.dlg;

import com.google.gwt.user.client.Command;

public class ModuleInfo{
	public String name;
	public String imageUrl;
	public String info;
	public Command command;
	public String originalName;
}

