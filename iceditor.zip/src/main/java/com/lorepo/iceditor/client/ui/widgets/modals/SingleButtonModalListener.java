package com.lorepo.iceditor.client.ui.widgets.modals;

public interface SingleButtonModalListener {
	public void onAccept();
}
