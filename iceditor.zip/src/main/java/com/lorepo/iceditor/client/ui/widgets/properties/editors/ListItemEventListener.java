package com.lorepo.iceditor.client.ui.widgets.properties.editors;

public interface ListItemEventListener {
	public void onMoveUp();
	public void onMoveDown();
	public void onRemove();
}
