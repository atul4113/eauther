package com.lorepo.iceditor.client.ui.widgets.properties;

public interface BooleanPropertyChangeListener {
	void onChange(boolean selected);
}
