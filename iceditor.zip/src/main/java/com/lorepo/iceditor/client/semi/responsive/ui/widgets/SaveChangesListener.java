package com.lorepo.iceditor.client.semi.responsive.ui.widgets;

import com.lorepo.icplayer.client.model.layout.PageLayout;

public interface SaveChangesListener {

	void saveChanges(PageLayout pageLayout);
}
