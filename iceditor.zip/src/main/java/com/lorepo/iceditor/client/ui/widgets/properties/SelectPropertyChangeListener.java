package com.lorepo.iceditor.client.ui.widgets.properties;

public interface SelectPropertyChangeListener {
	void onChange(String value);
}
