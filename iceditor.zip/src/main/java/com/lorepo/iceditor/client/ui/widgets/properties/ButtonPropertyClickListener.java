package com.lorepo.iceditor.client.ui.widgets.properties;

public interface ButtonPropertyClickListener {
	void onSelected();
}
