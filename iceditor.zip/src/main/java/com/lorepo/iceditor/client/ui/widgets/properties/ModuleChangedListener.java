package com.lorepo.iceditor.client.ui.widgets.properties;

public interface ModuleChangedListener {
	public void onModuleChanged();
}
