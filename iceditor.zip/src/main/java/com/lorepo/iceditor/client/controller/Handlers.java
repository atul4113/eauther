package com.lorepo.iceditor.client.controller;

public enum Handlers {
	CloseEditorHandler
}
