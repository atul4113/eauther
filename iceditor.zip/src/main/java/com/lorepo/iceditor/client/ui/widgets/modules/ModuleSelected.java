package com.lorepo.iceditor.client.ui.widgets.modules;

public interface ModuleSelected {
	public void onModuleSelected();
}
