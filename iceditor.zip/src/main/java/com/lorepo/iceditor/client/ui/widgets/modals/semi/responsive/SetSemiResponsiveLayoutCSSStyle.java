package com.lorepo.iceditor.client.ui.widgets.modals.semi.responsive;

public interface SetSemiResponsiveLayoutCSSStyle {
	void onDecline();
	void onSetSemiResponsiveLayoutCSSStyle(String styleID);
}
