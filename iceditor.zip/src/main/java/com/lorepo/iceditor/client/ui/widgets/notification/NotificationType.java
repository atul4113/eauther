package com.lorepo.iceditor.client.ui.widgets.notification;

public enum NotificationType {
	success,
	warning,
	notice,
	error
}
