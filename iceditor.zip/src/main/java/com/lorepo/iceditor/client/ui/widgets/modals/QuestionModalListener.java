package com.lorepo.iceditor.client.ui.widgets.modals;

public interface QuestionModalListener {
	public void onAccept();
	public void onDecline();
}
