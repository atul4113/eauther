package com.lorepo.iceditor.client.ui.widgets.properties.editors.richTextToolbar;

import java.util.Map;

public interface VisibilityConfiguration {
	Map<String, Boolean> getConfiguration();
}
