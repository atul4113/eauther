package com.lorepo.iceditor.client.ui.widgets.properties.editors;

interface RenderEditor {
	boolean getRenderOption();
	void changeRenderOption();
	void imageAdded();
	void audioAdded();
}