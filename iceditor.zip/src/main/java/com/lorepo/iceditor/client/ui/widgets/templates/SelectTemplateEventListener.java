package com.lorepo.iceditor.client.ui.widgets.templates;

public interface SelectTemplateEventListener {
	public void onTemplateSelected(String templateName, String themeURL, boolean replaceCommons);
}
