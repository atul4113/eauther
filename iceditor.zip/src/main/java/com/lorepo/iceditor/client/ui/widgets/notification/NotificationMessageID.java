package com.lorepo.iceditor.client.ui.widgets.notification;

public enum NotificationMessageID {
	too_many_pages
}
