package com.lorepo.iceditor.client.ui.widgets.modals.semi.responsive;

import com.lorepo.icplayer.client.model.CssStyle;

public interface AddNewStyle {
	
	public void onAddStyle(CssStyle newCssStyle);
	public void onDecline();
}
