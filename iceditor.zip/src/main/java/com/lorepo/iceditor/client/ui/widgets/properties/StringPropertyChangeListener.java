package com.lorepo.iceditor.client.ui.widgets.properties;

public interface StringPropertyChangeListener {
	void onChange(String value);
}
