package com.lorepo.iceditor.client.ui.widgets.properties.editors.richTextToolbar;

public class TextVisibilityConfiguration extends DefaultOptionVisiblityConfiguration {
	protected Boolean getInsertAudioVisibility() {
		return true;
	}
}
