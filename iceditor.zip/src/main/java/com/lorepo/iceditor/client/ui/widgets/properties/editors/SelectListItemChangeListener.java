package com.lorepo.iceditor.client.ui.widgets.properties.editors;

public interface SelectListItemChangeListener {
	void onChange(String value);
}
