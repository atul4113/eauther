package com.lorepo.iceditor.client.actions.api;

import com.lorepo.icplayer.client.model.page.Page;

public interface IPlayerEditor {

	void setHeader(Page page);

	void setFooter(Page page);

}
