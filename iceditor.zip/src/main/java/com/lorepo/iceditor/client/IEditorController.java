package com.lorepo.iceditor.client;

import com.lorepo.icplayer.client.IPlayerController;

public interface IEditorController extends IPlayerController {
	public void setCurrentPageIndex(int index);
}
