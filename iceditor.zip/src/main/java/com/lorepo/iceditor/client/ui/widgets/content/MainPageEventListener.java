package com.lorepo.iceditor.client.ui.widgets.content;

public interface MainPageEventListener {
	public void onSave();
	public void onApply();
}
