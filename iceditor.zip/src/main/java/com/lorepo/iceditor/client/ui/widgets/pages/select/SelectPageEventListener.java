package com.lorepo.iceditor.client.ui.widgets.pages.select;

import com.lorepo.icplayer.client.module.api.player.IPage;

public interface SelectPageEventListener {
	public void onPageSelected(IPage page);
}
