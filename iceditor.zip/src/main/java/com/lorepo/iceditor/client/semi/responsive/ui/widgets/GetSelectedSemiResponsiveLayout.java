package com.lorepo.iceditor.client.semi.responsive.ui.widgets;

public interface GetSelectedSemiResponsiveLayout {
	public String getValue();
}
