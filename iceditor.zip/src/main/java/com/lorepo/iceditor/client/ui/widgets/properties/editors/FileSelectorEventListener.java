package com.lorepo.iceditor.client.ui.widgets.properties.editors;

public interface FileSelectorEventListener {
	public void onSelected(String filePath);
}
