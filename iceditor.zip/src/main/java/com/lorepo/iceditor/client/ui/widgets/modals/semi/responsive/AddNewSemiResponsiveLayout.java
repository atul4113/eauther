package com.lorepo.iceditor.client.ui.widgets.modals.semi.responsive;


public interface AddNewSemiResponsiveLayout {
	public void onDecline();
	public void onAddNewSemiResponsiveLayout(PageLayoutData pageLayoutData);
}
