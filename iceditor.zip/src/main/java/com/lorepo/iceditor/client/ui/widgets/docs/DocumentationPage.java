package com.lorepo.iceditor.client.ui.widgets.docs;

public class DocumentationPage {
	public String name;
	public String html;
	
	public DocumentationPage (String name, String html) {
		this.name = name;
		this.html = html;
	}
}
