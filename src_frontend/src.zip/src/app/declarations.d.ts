declare namespace Observable {
    let forkJoin: any;
    let of: any;
}
