export class RadioOption {
    constructor(
        public readonly content: string,
        public readonly value: string | number | boolean
    ) {}
}
