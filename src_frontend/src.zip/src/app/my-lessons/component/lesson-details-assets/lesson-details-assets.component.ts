import { Component, Input, OnChanges, OnInit, ViewChild } from '@angular/core';

import { UploadFileComponent } from "../../../common/component/upload-file/upload-file.component";
import { Asset } from "../../model/asset";
import { Lesson, LESSONS_ORDER_KEYS, LessonsOrder } from "../../model/lesson";
import { FileData, UploadFileError, ITranslations } from "../../../common/model";
import { InfoMessageService, TranslationsService } from "../../../common/service";
import { MyContentService } from "../../service/my-content.service";
import { CookieService } from "../../../common/service/cookie/cookies.service";
import { RolePermissions } from "../../../common/model/auth-user";

@Component({
    selector: 'app-lesson-details-assets',
    templateUrl: './lesson-details-assets.component.html'
})
export class LessonDetailsAssetsComponent implements OnInit, OnChanges {
    @ViewChild('uploadFileUniqueId') uploadFile!: UploadFileComponent;

    @Input() lesson!: Lesson;
    @Input() assets: Asset[] = [];
    @Input() assetsLoaded: boolean = false;
    @Input() userPermissions!: RolePermissions;

    public paginatedAssets: number = 1;
    public assetsPageSize: number = 5;
    public file: FileData | null = null;
    public isFileUploading: boolean = false;
    public sortedNameUp: boolean = false;
    private _assets: Asset[] = [];
    private _searchPhrase: string = '';
    public translations: ITranslations | null = null;
    public assetsOrder: LessonsOrder = new LessonsOrder();
    public isUploadDisabled: boolean = false;

    constructor(
        private _myContent: MyContentService,
        private _infoMessage: InfoMessageService,
        private _translations: TranslationsService,
        private _cookie: CookieService
    ) {}

    ngOnInit(): void {
        this._translations.getTranslations().subscribe(t => this.translations = t);
    }

    ngOnChanges(): void {
        this.detectSort();
        this._assets = this.assets;
    }

    public get searchPhrase(): string {
        return this._searchPhrase;
    }

    public set searchPhrase(value: string) {
        this._searchPhrase = value;
        this.search();
    }

    public search(): void {
        const phrase = this.searchPhrase.trim().toLowerCase();

        this.assets = this._assets
            .filter(asset =>
                asset.fileName.toLowerCase().indexOf(phrase) > -1 ||
                asset.title.toLowerCase().indexOf(phrase) > -1 ||
                asset.contentType.toLowerCase().indexOf(phrase) > -1 ||
                asset.href.toLowerCase().indexOf(phrase) > -1);
    }

    public onFileSelected(file: FileData): void {
        this.file = file;
        this.doUpload();
    }

    public doUpload(): void {
        if (!this.file) return;

        this.isFileUploading = true;

        if (!this.file.isUploaded) {
            const uploadMessage = this.translations?.labels['file.uploading'] ?? "Uploading file: " + this.file.name;
            this._infoMessage.addInfo(uploadMessage, true);
            this.isUploadDisabled = true;
            this.uploadFile.upload().subscribe(
                (uploadedFile: FileData) => {
                    this.file = uploadedFile;
                    if (this.file.type.indexOf("zip") > -1) {
                        this.savePackage();
                    } else {
                        this.saveFile();
                    }
                },
                (error: UploadFileError) => {
                    const errorMessage = this.translations?.labels['file.upload.error'] ?? "File has NOT been uploaded";
                    this._infoMessage.addError(errorMessage);
                },
                () => {
                    this.isFileUploading = false;
                }
            );
        }
    }

    private savePackage(): void {
        if (!this.file) return;

        this._myContent.uploadAssetPackage(this.lesson.id, { fileId: this.file.fileId }).subscribe(
            () => {
                const successMessage = this.translations?.labels['plain.my_lessons.lesson_details_assets.package_uploaded'] ?? 'Package uploaded successfully';
                this._infoMessage.addSuccess(successMessage);
                this._myContent.getLessonAssets(this.lesson.id).subscribe((assets: Asset[]) => {
                    this.assets = assets;
                    this.detectSort();
                    this.file = null;
                    this.isUploadDisabled = false;
                });
                this.detectSort();
            },
            () => {
                const errorMessage = this.translations?.labels['plain.my_lessons.lesson_details_assets.package_upload_error'] ?? 'Failed to upload package';
                this._infoMessage.addError(errorMessage);
                this.file = null;
            }
        );
    }

    private saveFile(): void {
        if (!this.file) return;

        this._myContent.uploadAsset(this.lesson.id, { fileId: this.file.fileId }).subscribe(
            () => {
                const successMessage = this.translations?.labels['file.save.success'] ?? 'File saved successfully';
                this._infoMessage.addSuccess(successMessage);
                this.assets = [Asset.fromFile(this.file!), ...this.assets];
                this.detectSort();
                this.file = null;
                this.isUploadDisabled = false;
            },
            () => {
                const errorMessage = this.translations?.labels['file.save.error'] ?? 'File has NOT been saved';
                this._infoMessage.addError(errorMessage);
                this.file = null;
            }
        );
    }

    public getAssetType(asset: Asset): string {
        if (asset.contentType) {
            return asset.contentType.split("/")[0];
        } else {
            return "Unknown";
        }
    }

    public getAssetFormat(asset: Asset): string {
        if (asset.contentType) {
            return asset.contentType.split("/")[1];
        } else {
            return "Unknown";
        }
    }

    public getAssetImage(asset: Asset): string {
        if (asset.contentType.indexOf("image") !== -1) {
            return asset.href;
        } else if (asset.contentType.indexOf("audio") !== -1) {
            return "/media/images/default_audio_resource_icon.png";
        } else if (asset.contentType.indexOf("video") !== -1) {
            return "/media/images/default_video_resource_icon.png";
        } else {
            return "/media/images/default_binary_resource_icon.png";
        }
    }

    public sortAssetsBy(sortBy: string): void {
        if (LESSONS_ORDER_KEYS.has(sortBy)) {
            const order = LESSONS_ORDER_KEYS.get(sortBy);
            this.assetsOrder = new LessonsOrder(order);
            this.setCookieSortBy(sortBy);
            this.assets = this.assets.filter(asset => asset.size !== 0);
            this._assets = this.assets;

            if (this.assetsOrder.isDateDown()) {
                this.assets.sort((a: Asset, b: Asset) => (a.createdDate > b.createdDate) ? 1 : ((b.createdDate > a.createdDate) ? -1 : 0));
            } else if (this.assetsOrder.isDateUp()) {
                this.assets.sort((a: Asset, b: Asset) => (a.createdDate < b.createdDate) ? 1 : ((b.createdDate < a.createdDate) ? -1 : 0));
            } else if (this.assetsOrder.isNameDown()) {
                this.assets.sort((a: Asset, b: Asset) => (a.fileName > b.fileName) ? 1 : ((b.fileName > a.fileName) ? -1 : 0));
            } else if (this.assetsOrder.isNameUp()) {
                this.assets.sort((a: Asset, b: Asset) => (a.fileName < b.fileName) ? 1 : ((b.fileName < a.fileName) ? -1 : 0));
            }
        }
    }

    public sortAssetsByNameDown(): void {
        this.sortAssetsBy('nameDown');
    }

    public sortAssetsByNameUp(): void {
        this.sortAssetsBy('nameUp');
    }

    public sortAssetsByDateDown(): void {
        this.sortAssetsBy('dateDown');
    }

    public sortAssetsByDateUp(): void {
        this.sortAssetsBy('dateUp');
    }

    public setCookieSortBy(value: string): void {
        const dateYearPlus = new Date();
        dateYearPlus.setTime(dateYearPlus.getTime() + (365 * 24 * 3600 * 1000));
        this._cookie.put('assetsOrderBy' + this.lesson.id, value, { expires: dateYearPlus });
    }

    public detectSort(): void {
        const cookieOrder = this._cookie.get('assetsOrderBy' + this.lesson.id);
        if (cookieOrder !== undefined) {
            this.sortAssetsBy(cookieOrder);
        } else {
            this.sortAssetsBy('dateUp');
        }
    }
}
