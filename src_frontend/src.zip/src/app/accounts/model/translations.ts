export interface ITranslations {
    labels: {[key: string]: string};
    images: {[key: string]: string};
}
