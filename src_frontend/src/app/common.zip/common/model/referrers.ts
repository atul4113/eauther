export interface Referrers {
    [key: string]: string;
}
