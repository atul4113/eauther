export class CheckboxOption {
    constructor (
        public content: string,
        public value: any
    ) {}
}
