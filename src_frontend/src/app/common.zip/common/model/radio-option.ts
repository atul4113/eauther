export class RadioOption {
    constructor (
        public content: string,
        public value: any
    ) {}
}